const controller = require('../controllers/controller');

module.exports = app => {
    
    // Create
    app.post('/api/users', controller.createUser);
    
    // Read
    app.get('/api/users', controller.allUsers);
   
    app.get('/api/users/:id', controller.oneUser);
    
    // Update
    app.patch('/api/users/:id', controller.updateUser);
    
    // Delete
    app.delete('/api/users/:id/', controller.deleteUser);
}
