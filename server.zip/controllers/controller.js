const User = require('../models/User');

module.exports = {
    // Create
    createUser: (req, res) => {
        const { firstName, lastName } = req.body;
        console.log(req.body)
        User.create({
            firstName,
            lastName
        })
    },
    // Read
    allUsers: (req,res) => {
        User.findAll()
            .then(data => res.json({ message: "success", data }))
            .catch(err => res.json({ message: "error", data: err }));
    },
    oneUser: (req,res) => {
        User.findAll({ where: { id: req.params.id }})
        .then(data => res.json({ message: "success", data: data }))
        .catch(err => res.json({ message: "error", data: err }));

    },
    // Update
    updateUser: (req,res) => {

    },
    // Delete
    deleteUser: (req,res) => {
        User.destroy({ where: { id: req.params.id }})
        .then(data => res.json({ message: "success", data: data }))
        .catch(err => res.json({ message: "error", data: err }));

    }
}