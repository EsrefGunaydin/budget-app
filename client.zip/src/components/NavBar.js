import React from 'react'
import { Link } from "@reach/router"
import '../App.css'

const NavBar = () => {
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-light bg-light bd-navbar">
                <div className="container-fluid">
                    <Link className="navbar-brand" to="/">Expanse Tracker</Link>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                    </button>
                <div className="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div className="navbar-nav">
                        <Link className="nav-item nav-link" to="/transactions"> Transactions</Link>
                        <Link className="nav-item nav-link" to="/filters"> Filters</Link>
                        <Link className="nav-item nav-link" to="/loans"> Loans</Link>
                        <Link className="nav-item nav-link" to="/creditcards"> Credit Cards</Link>
                        <Link className="nav-item nav-link" to="/profile"> Profile</Link>
                        <Link className="nav-item nav-link" to="/stats"> Stats</Link>
                    </div>
                </div>
                </div>
            </nav>
        </div>
    )
}

export default NavBar
