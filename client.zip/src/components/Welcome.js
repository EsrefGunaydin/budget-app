import React from 'react'

const Welcome = () => {
    return (
        <div>
            <div className="jumbotron">
                <h2 className="display-4">Expanse Tracker v.0.0.1</h2>
                <p className="lead"><strong>'Expanse Tracker'</strong> aims to provide easy, flexible, personalized budget management   </p>
            </div>
        </div>
    )
}

export default Welcome
