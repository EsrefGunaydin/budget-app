import React from 'react'

const CreditCards = () => {
    return (
        <div className="container m-2">
            Credit Cards will appear here
        </div>
    )
}

export default CreditCards
