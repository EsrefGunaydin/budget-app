import React from 'react'

const Loans = () => {
    return (
            <div className="container m-2">
            <h4>&#8853; New</h4>
            <table class="table w-75">
            <thead>
                <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">Balance</th>
                <th scope="col">Terms Left</th>
                <th scope="col">Original Terms</th>
                <th scope="col">Payments</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <th scope="row">1</th>
                <td>Bike For Cassy</td>
                <td>$ 110</td>
                <td>11</td>
                <td>20</td>
                <td>$ 10</td>
                </tr>
                <tr>
                <th scope="row">2</th>
                <td>Honda Repair</td>
                <td>$ 400</td>
                <td>7</td>
                <td>8</td>
                <td>50</td>
                </tr>
                <tr>
                <th scope="row">3</th>
                <td>...</td>
                <td>...</td>
                <td>...</td>
                <td>...</td>
                <td>...</td>
                </tr>
            </tbody>
            </table>
        </div>
    )
}

export default Loans
