import { useState, useEffect } from 'react'
import axios from 'axios';
import { Link } from '@reach/router';

const Stats = () => {

    const [ users, setUsers ] = useState([])

    useEffect(()=> {
        axios.get('http://localhost:5000/api/users')
            .then(res => setUsers(res.data.data))
            .catch(err => console.log(err));
    }, [])

    const deleteHandler = (id)=>{
        
        axios.delete(`http://localhost:5000/api/users/${id}`)
            .then(() => { setUsers(users.filter((user) => user.id != id)) })
            .catch(err => console.log(err));
    }

    return (
        <div className="container m-2">
            <h1>Users</h1>
            { console.log(users)}
            <ul>
            {
                users.map((user, i) => <li key={i}>{user.firstName} {user.lastName} 
                <Link to={`/edit/${user.id}`}> Edit</Link> | 
                <button className="btn btn-link" 
                        onClick={() => deleteHandler(user.id)}>Delete</button></li> )
            }
            </ul>
        </div>
    )
}

export default Stats
