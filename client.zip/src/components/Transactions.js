import { React, useState } from 'react'
import axios from 'axios';
import { navigate } from '@reach/router';

const Transactions = () => {

    const [ firstName, setFirstName ] = useState('');
    const [ lastName, setLastName ] = useState('')

  const onSubmitHandler = (e)=>{
    e.preventDefault();
    // console.log(firstName + lastName)
    const user = { firstName, lastName 
    }
    axios.post('http://localhost:5000/api/users', user)
    .then(res => {
      console.log(res)
    })
    .catch(err => console.log(err));
    navigate("/stats");
  }

    return (
        <div className="container m-2">
          <form onSubmit={onSubmitHandler} className="w-50 p-3">
            <div className="form-group">
              <label htmlFor="firstName">First Name</label>
              <input className="form-control" onChange={(e)=> setFirstName(e.target.value)} type="text"/><br />
            </div>
            <div className="form-group">
              <label htmlFor="lastName">Last Name</label>
              <input className="form-control" onChange={(e)=> setLastName(e.target.value)} type="text"/><br />
            </div>
            <button  className="btn btn-primary">Submit</button>             
          </form>
        </div>
    )
}

export default Transactions
