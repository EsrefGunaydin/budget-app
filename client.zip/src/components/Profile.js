import React from 'react'

const Profile = () => {
    return (
        <div className="container m-2">
            Profile will appear here
        </div>
    )
}

export default Profile
