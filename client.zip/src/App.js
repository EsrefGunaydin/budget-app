import { Router } from "@reach/router"
import Transactions from './components/Transactions';
import Filters from './components/Filters';
import Loans from './components/Loans';
import CreditCards from './components/CreditCards';
import Profile from './components/Profile';
import Stats from './components/Stats';
import NavBar from './components/NavBar';
import Welcome from "./components/Welcome";
import MainForm from "./components/MainForm";


function App() {

  return (
    <div className="App">
      <NavBar />
      <Router>
        <Welcome path="/"/>
        <Transactions path="/transactions"/>
        <Filters path="/filters"/>
        <Loans path="/loans"/>
        <MainForm path="/creditcards"/>
        <Profile path="/profile"/>
        <Stats path="/stats"/>
      </Router>
    </div>
  );
}

export default App;
